export class Passenger {
    id?: number;
    pnr?: number;
    name?:string;
    age?:number;
    seat?:number;
}
