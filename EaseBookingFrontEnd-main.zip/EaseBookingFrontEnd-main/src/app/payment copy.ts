export class Payment2 {
    paymentId?:number;
    payAmount?:number;
    payStatus?:string;
    upiId?:string;
    seatNumber?:number;
    
}
