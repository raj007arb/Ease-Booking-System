import { Payment } from './payment';

describe('Payment2', () => {
  it('should create an instance', () => {
    expect(new Payment()).toBeTruthy();
  });
});
