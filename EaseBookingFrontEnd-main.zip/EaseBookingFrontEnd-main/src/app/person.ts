export class Person{
   
    email?:String;
    firstname?:String;
    lastname?:String;
    dob?:Date;
    contact?:number;
    password?:String;


}