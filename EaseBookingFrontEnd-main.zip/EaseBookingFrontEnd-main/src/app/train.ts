export class Train {
    seatNumber?:number;
    trainNumber?: number;
    trainName?: string;
    dateOfJourney?: Date;
    pName?: string;
    age?: number;
    source?: string;
    destination?: string;
    coach?: string;
    birthPreference?: string;
}
