export class Payment {
    id?:number;
    pnr?:number;
    upi?:string;
    amount?:number;
    date?:Date;
}
